

  <?php
  include_once 'partials/head.php';
$activePage = "about.php";?>
<div class="hero">
   <?php
  include_once 'partials/header.php'; ?>
  <div class="hero__content">
    <h1>About us</h1>
    <p class="hero__content__text">
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam nulla deserunt doloremque, quo, accusantium eos dolores accusamus dolorum alias error fuga ad quibusdam at quia. Facilis porro soluta, libero saepe.

  </div>
</div>


<div class="content__contain">

<img src="img/book.jpg" alt="">
<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur rem odit laboriosam esse! Enim voluptate nam exercitationem inventore, illum consequatur asperiores ratione architecto maiores fugit. Assumenda, nesciunt at nobis est.</p>
</div>

<?php include_once 'partials/footer.php'; ?>
