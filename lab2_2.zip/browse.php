

  <?php
  // database

  $books = array();
  $books[] = array("title" => "RUM", "author" => "Alexander Schulman");
  $books[] = array("title" => "Pippi Långstrump", "author" => "Astrid Lindgren");
  $books[] = array("title" => "Stora pekboken", "author" => "Anonoym Anonymsson");
  $books[] = array("title" => "Vem vet", "author" => "Elsa Svensson");
  $books[] = array("title" => "The Book", "author" => "John Doe");


  include_once 'partials/head.php';
  $activePage = "browse.php";?>
  <div class="hero">
     <?php
    include_once 'partials/header.php'; ?>
    <div class="hero__content">
      <h1>Browse books</h1>
      <p class="hero__content__text">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Magnam nulla deserunt doloremque, quo, accusantium eos dolores accusamus dolorum alias error fuga ad quibusdam at quia. Facilis porro soluta, libero saepe.

    </div>
  </div>


  <div class="content__contain">
  			<div id="search">
          <form method="GET">
            <INPUT type="text" name="searchtitle" placeholder="Search title or author">
            <INPUT type="submit" name="submit" value="Search">
          </form>
  		  </div>





      <?php
      if (isset($_GET) && !empty($_GET)) {
          $searchtitle = trim($_GET['searchtitle']);
          $searchtitle = addslashes($searchtitle);
          $id = array_search($searchtitle, array_column($books, 'title'));
          $id2 = array_search($searchtitle, array_column($books, 'author'));

          if ($id !== FALSE) {
            $book = $books[$id];
            $title = $book['title'];
            $author = $book['author'];
            ?>
            <div id="list">
            <ul class="booklist">
            <li>

              <p> <span class="Name"><?php echo $title;  ?></span> by

              <span class="Author"><?php echo $author;  ?> </span></p>
              <div class="btns">
              <form action="" method="post">
                <input type="submit" value='' id="book">
              </form>
              </div>



            </li>
</ul></div>

            <?php
          } elseif ($id2 !== FALSE ) {
            $book = $books[$id2];
            $title = $book['title'];
            $author = $book['author'];
            ?>
            <div id="list">
            <ul class="booklist">
            <li>

              <p> <span class="Name"><?php echo $title;  ?></span> by

              <span class="Author"><?php echo $author;  ?> </span></p>
              <div class="btns">
              <form action="" method="post">
                <input type="submit" value='' id="book">
              </form>
              </div>



            </li>
              </ul>
            </div>

            <?php

          }

      }

      else {?>
        <div id="list">


        <ul class="booklist">
          <?php foreach ($books as $book) {
                      $title = $book['title'];
                      $author = $book['author'];


                   ?>
          <li>

            <p ><span class="Name"><?php echo $title;  ?></span> by

            <span class="Author"><?php echo $author;  ?> </span></p>
            <div class="btns">
            <form action="" method="post">
              <input type="submit" value='' id="book">
            </form>
            </div>



          </li>

        <?php } ?>
              </ul></div>


        <?php

      }





      ?>








</div>

<?php include_once 'partials/footer.php'; ?>
