<footer>
<p class="copyright">Emma Kihlberg &copy; <?php echo date("Y"); ?></p>

</footer>
</div>

</body>
</html>
